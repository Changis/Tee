/**
 * Created by David Chang on 2016-10-27.
 */
var app = angular.module('mainApp', []);
app.controller('mainController', function($scope, $http, $interval) {

    $scope.dbReply = "N/A";
    $scope.pname = "glader";
    $scope.searchedId = 1;
    $scope.getAllNames = function () {
        // $http.get("http://localhost:8080/Tee-1.0-SNAPSHOT/api/get/all").then(function(response){
        $http.get("/api/get/all").then(function(response){
            $scope.dbReply = response.data;
        });
    };

    $scope.addPerson = function(){
        $http.get("http://localhost:8080/Tee-1.0-SNAPSHOT/api/add/"+$scope.pname).then(function(response){
            $scope.dbReply = response.data;
        });
    };

    $scope.getNameById = function(){
        $http.get("/api/get/"+$scope.searchedId).then(function(response){
            $scope.dbReply = response.data;
        });
    };

    $scope.halp = function(){
        alert("halp. me. ");
    };

    $scope.theTime = new Date().toLocaleTimeString();
    $interval(function(){
        $scope.theTime = new Date().toLocaleTimeString();
    }, 1000);

});